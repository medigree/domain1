
The openHIE template for FHIR IGs

To use it, simply set  
   `template = openhie.fhir.template#current`
   
in your ImplementationGuide's ig.ini
 
